const solution = (x, y) => {
    if (x === 0 || y === 0 || x === y) {return "1"}

    const player2 = [[1, 2], [2, 1]]

    for (let i = 0; i <= x; i++) {
        for (let j = 0; j <= y; j++) {
            const check = player2.map(coord => {
                return (i === coord[0] || j === coord[1] || i-coord[0] === j - coord[1])
            })

            if (!check.filter( bool => bool ).length) {
                player2.push([i,j])
            }
        }
    }

    return player2.filter(coords => { return coords[0] === x && coords[1] === y}).length ? "2" : "1"
}

if (!process.argv[2] || !process.argv[3]) {
    console.log(Error) 
} else {
    console.log(solution(Number(process.argv[2]), Number(process.argv[3])))
}
